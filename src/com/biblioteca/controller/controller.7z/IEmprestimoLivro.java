package com.biblioteca.controller;

import com.biblioteca.model.EmprestimoLivroModel2;
import java.util.ArrayList;

/**
 *
 * @author Instrutores
 */
public interface IEmprestimoLivro {

    public boolean salvarEmprestimosLivrosDAO(EmprestimoLivroModel2 pModelEmprestimosLivros);
    public boolean salvarEmprestimosLivrosDAO(ArrayList<EmprestimoLivroModel2> plistaModelEmprestimosLivros);
    public boolean excluirEmprestimosLivrosDAO(int pIdEmprestimoLivro);
    public boolean atualizarEmprestimosLivrosDAO(EmprestimoLivroModel2 pModelEmprestimosLivros);
    public ArrayList<EmprestimoLivroModel2> getListaEmprestimosLivrosDAO();
    public EmprestimoLivroModel2 getEmprestimosLivrosDAO(int pIdEmprestimoLivro);
}
