package com.biblioteca.controller;

import com.biblioteca.model.EmprestimoLocatarioModel2;
import java.util.ArrayList;

/**
 *
 * @author Instrutores
 */
public interface IEmprestimoLocatario {

    public ArrayList<EmprestimoLocatarioModel2> getListaEmprestimosLocatarioDAO();
}
