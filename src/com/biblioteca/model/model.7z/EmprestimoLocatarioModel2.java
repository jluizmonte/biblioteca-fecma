package com.biblioteca.model;

import java.util.ArrayList;

/**
 *
 * @author Instrutores
 */
public class EmprestimoLocatarioModel2 {

    private EmprestimoModel emprestimoModel;
    private LocatarioModel locatarioModel;
    private LocadorModel locadorModel;
    private LivroModel livroModel;
    private EmprestimoLivroModel2 emprestimoLivroModel;
    private ArrayList<EmprestimoLivroModel2> listaEmprestimoLivroModel;

    public EmprestimoModel getEmprestimoModel() {
        return emprestimoModel;
    }

    public void setEmprestimoModel(EmprestimoModel emprestimoModel) {
        this.emprestimoModel = emprestimoModel;
    }

    public LocatarioModel getLocatarioModel() {
        return locatarioModel;
    }

    public void setLocatarioModel(LocatarioModel locatarioModel) {
        this.locatarioModel = locatarioModel;
    }

    public LocadorModel getLocadorModel() {
        return locadorModel;
    }

    public void setLocadorModel(LocadorModel locadorModel) {
        this.locadorModel = locadorModel;
    }

    public LivroModel getLivroModel() {
        return livroModel;
    }

    public void setLivroModel(LivroModel livroModel) {
        this.livroModel = livroModel;
    }

    public EmprestimoLivroModel2 getEmprestimoLivroModel() {
        return emprestimoLivroModel;
    }

    public void setEmprestimoLivroModel(EmprestimoLivroModel2 emprestimoLivroModel) {
        this.emprestimoLivroModel = emprestimoLivroModel;
    }

    public ArrayList<EmprestimoLivroModel2> getListaEmprestimoLivroModel() {
        return listaEmprestimoLivroModel;
    }

    public void setListaEmprestimoLivroModel(ArrayList<EmprestimoLivroModel2> listaEmprestimoLivroModel) {
        this.listaEmprestimoLivroModel = listaEmprestimoLivroModel;
    }

}
