package com.biblioteca.service;

import com.biblioteca.model.EmprestimoLivroModel2;
import com.biblioteca.model.dao.EmprestimoLivroDao;
import java.util.ArrayList;

/**
 *
 * @author José Luiz
 */
public class EmprestimoLivroService {

    EmprestimoLivroDao emprestimoLivroDao = new EmprestimoLivroDao();

    public boolean salvarEmprestimosLivrosDAO(EmprestimoLivroModel2 pModelEmprestimosLivros) {
        return emprestimoLivroDao.salvarEmprestimosLivrosDAO(pModelEmprestimosLivros);
    }

    public boolean salvarEmprestimosLivrosDAO(ArrayList<EmprestimoLivroModel2> plistaModelEmprestimosLivros) {
        return emprestimoLivroDao.salvarEmprestimosLivrosDAO(plistaModelEmprestimosLivros);
    }

    public boolean excluirEmprestimosLivrosDAO(int pIdEmprestimoLivro) {
        return emprestimoLivroDao.excluirEmprestimosLivrosDAO(pIdEmprestimoLivro);
    }

    public boolean atualizarEmprestimosLivrosDAO(EmprestimoLivroModel2 pModelEmprestimosLivros) {
        return emprestimoLivroDao.atualizarEmprestimosLivrosDAO(pModelEmprestimosLivros);
    }

    public ArrayList<EmprestimoLivroModel2> getListaEmprestimosLivrosDAO() {
        return emprestimoLivroDao.getListaEmprestimosLivrosDAO();
    }

    public EmprestimoLivroModel2 getEmprestimosLivrosDAO(int pIdEmprestimoLivro) {
        return emprestimoLivroDao.getEmprestimosLivrosDAO(pIdEmprestimoLivro);
    }

}
