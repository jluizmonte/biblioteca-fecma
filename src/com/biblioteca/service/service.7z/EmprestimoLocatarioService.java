package com.biblioteca.service;

import com.biblioteca.model.EmprestimoLocatarioModel2;
import com.biblioteca.model.dao.EmprestimoLocatarioDao;
import java.util.ArrayList;

/**
 *
 * @author José Luiz
 */
public class EmprestimoLocatarioService {

    EmprestimoLocatarioDao emprestimoLocatarioDao = new EmprestimoLocatarioDao();

    public ArrayList<EmprestimoLocatarioModel2> getListaEmprestimosLocatarioDAO() {
        return emprestimoLocatarioDao.getListaEmprestimosLocatarioDAO();
    }
}
